# Changelog

Toute modification liée au code exécuté en production sera documentée dans ce fichier.

Le présent format s'appuie sur [Keep a Changelog](http://keepachangelog.com/en/1.0.0/).

Ce fichier ne doit pas être mis à jour directement, il faut utiliser le fichier
`CHANGELOG-UNRELEASED.md`.
Par la suite les changements de `CHANGELOG-UNRELEASED.md` sont reversés dans ce
fichier lors de la création d'une nouvelle release.

## 
