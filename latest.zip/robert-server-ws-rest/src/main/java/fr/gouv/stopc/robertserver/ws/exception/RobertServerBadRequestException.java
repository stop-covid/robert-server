package fr.gouv.stopc.robertserver.ws.exception;

public class RobertServerBadRequestException extends RobertServerException {

	private static final long serialVersionUID = 1L;

	public RobertServerBadRequestException(String message) {

		super(message);
	}
}
