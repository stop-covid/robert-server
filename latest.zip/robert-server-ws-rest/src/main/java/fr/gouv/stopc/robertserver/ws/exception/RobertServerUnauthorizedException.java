package fr.gouv.stopc.robertserver.ws.exception;

public class RobertServerUnauthorizedException extends RobertServerException {

    private static final long serialVersionUID = 1L;

    public RobertServerUnauthorizedException(String message) {

        super(message);
    }

}
