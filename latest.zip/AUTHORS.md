Ce composant à été écrit par
* Groupe Capgemini (Capgemini, Idean, Sogeti)

Les personnes suivantes ont contribué
* Pour Groupe Capgemini (Capgemini, Idean, Sogeti)
    * redford.stopcovid@idean.com
    * palmer.stopcovid@capgemini.com
    * marley.stopcovid@capgemini.com
    * trujillo.stopcovid@capgemini.com
    * julia.stopcovid@capgemini.com
    * stanley.stopcovid@capgemini.com
    * benigni.stopcovid@capgemini.com
    * deniro.stopcovid@capgemini.com
    