package fr.gouv.stopc.robertserver.crypto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RobertServerCryptoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RobertServerCryptoApplication.class, args);
	}

}
