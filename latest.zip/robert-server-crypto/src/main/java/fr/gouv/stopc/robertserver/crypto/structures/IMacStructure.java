package fr.gouv.stopc.robertserver.crypto.structures;

import javax.crypto.Mac;

public interface IMacStructure {

    Mac getMac();
}
