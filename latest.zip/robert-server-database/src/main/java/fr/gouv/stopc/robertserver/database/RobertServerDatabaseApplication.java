package fr.gouv.stopc.robertserver.database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RobertServerDatabaseApplication {

	public static void main(String[] args) {

		SpringApplication.run(RobertServerDatabaseApplication.class, args);
	}

}

