package test.fr.gouv.stopc.robertserver.database;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class RobertServerDatabaseApplicationTest {
	
	@Test
	void contextLoads() {
	}

}
